using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HighScore : MonoBehaviour
{
    Text highScoreText;
    // Start is called before the first frame update
    void Start()
    {
        highScoreText = GetComponent<Text>();

        Debug.Log(MissionDemolition.HighShots);
        if (MissionDemolition.points == MissionDemolition.HighPoints)
        {
            highScoreText.text = "New Highscore= Shots: " + MissionDemolition.HighShots + " Highscore: " + MissionDemolition.HighPoints;
        }
        else
        {
            highScoreText.text = "Highscore= Shots: " + MissionDemolition.HighShots + " Highscore: " + MissionDemolition.HighPoints;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
