using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public enum GameMode
{
    idle,
    playing,
    levelEnd
}

public class MissionDemolition : MonoBehaviour
{
    static private MissionDemolition S;
    static public int HighShots = 28;
    static public int HighPoints = 0;
    static public int points = 0;

    [Header("Set in Inspector")]
    public Text uitLevel;  // The UIText_Level Text
    public Text uitShots;  // The UIText_Shots Text
    public Text uitButton; // The Text on UIButton_View
    public Text uitHighScore; // The Text on UIText_HighScore
    public Vector3 castlePos; // The place to put castles
    public GameObject[] castles;   // An array of the castles
    

    [Header("Set Dynamically")]
    public int level;     // The current level
    public int levelMax;  // The number of levels
    public int shotsTaken;
    public int totalShots = 0;
    public GameObject castle;    // The current castle
    public GameMode mode = GameMode.idle;
    public string showing = "Show Slingshot";

    // Start is called before the first frame update
    void Start()
    {
        S = this;

        level = 0;
        levelMax = castles.Length;

        if (PlayerPrefs.HasKey("ShotsTaken"))
        {
             HighShots = PlayerPrefs.GetInt("ShotsTaken");
            Debug.Log(HighShots);
        }

        if (PlayerPrefs.HasKey("Points"))
        {
            HighPoints = PlayerPrefs.GetInt("Points");
        }

        PlayerPrefs.SetInt("ShotsTaken", HighShots);
        PlayerPrefs.SetInt("Points", HighPoints);

        StartLevel();
    }

    void StartLevel()
    {
        if (castle != null)
        {
            Destroy(castle);
        }

        GameObject[] gos = GameObject.FindGameObjectsWithTag("Projectile");
        foreach(GameObject pTemp in gos)
        {
            Destroy(pTemp);
        }

        castle = Instantiate<GameObject>(castles[level]);
        castle.transform.position = castlePos;
        shotsTaken = 0;

        SwitchView("Show Both");
        ProjectileLine.S.Clear();

        Goal.goalmet = false;

        UpdateGUI();

        mode = GameMode.playing;
    }

    void UpdateGUI()
    {
        uitLevel.text = "Level: " + (level + 1) + " of " + levelMax;
        uitShots.text = "Shots Taken: " + shotsTaken;
        uitHighScore.text = "HighScore: " + HighShots + " shots, " + HighPoints + " Points";
    }

    // Update is called once per frame
    void Update()
    {
        UpdateGUI();

        if ((mode == GameMode.playing) && Goal.goalmet)
        {
            mode = GameMode.levelEnd;

            SwitchView("Show Both");

            Invoke("NextLevel", 2f);
        }
    }

    void NextLevel()
    {
        level++;
        totalShots += shotsTaken;

        if (level == levelMax)
        {
            int temp = totalShots * 100;
            points = 2800 - temp;
            Debug.Log(points);

            if(points < 0)
            {
                points = 0;
            }

            if (totalShots < PlayerPrefs.GetInt("ShotsTaken"))
            {
                HighShots = totalShots;
                PlayerPrefs.SetInt("ShotsTaken", totalShots);
            }
            if (points > PlayerPrefs.GetInt("Points"))
            {
                HighPoints = points;
                PlayerPrefs.SetInt("Points", points);
            }

            Debug.Log(HighPoints);
            SceneManager.LoadScene("Game_Over");
        }

        if (level < levelMax)
        {
            StartLevel();
        }
    }

    public void SwitchView(string eView = "")
    {
        if (eView == "")
        {
            eView = uitButton.text;
        }
        showing = eView;
        switch (showing)
        {
            case "Show Slingshot":
                FollowCam.POI = null;
                uitButton.text = "Show Castle";
                break;

            case "Show Castle":
                FollowCam.POI = S.castle;
                uitButton.text = "Show Both";
                break;

            case "Show Both":
                FollowCam.POI = GameObject.Find("ViewBoth");
                uitButton.text = "Show Slingshot";
                break;
        }
    }

    public static void ShotFired()
    {
        S.shotsTaken++;
    }
}
