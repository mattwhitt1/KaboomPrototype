using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchLevels : MonoBehaviour
{
    public void SwitchLevel(string level)
    {
        SceneManager.LoadScene(level);
    }
}
